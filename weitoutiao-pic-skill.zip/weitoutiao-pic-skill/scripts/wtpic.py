#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wtpic.py — 微头条配图流水线（自包含，无外部依赖，除 requests / Pillow）

【图源白名单 · 铁律】
  只允许两个平台：百度图片、小红书。
  360 / 搜狗 / 必应 / 头条站内 / 微博 / 各类图库（视觉中国、摄图网、千图、包图、
  站酷海洛、昵图网…）一律不找。脚本里已把 360 相关代码全部删除，不要加回来。

  百度图片：脚本自动抓（本文件唯一自动化图源）。
  小红书：纯前端渲染 + 要登录态，脚本**抓不到**（实测 2026-11 确认）。
          只能用①用户给的笔记链接，②浏览器控制真实打开。详见 SKILL.md「小红书怎么用」。

子命令：
  doctor                          检查依赖与图源连通性
  harvest --plan plan.json        按关键词计划抓候选图（缩略图），崩溃可续跑
  sheet   [--key K] [--pages 2]   把缩略图拼成 6x4 联系表，带 idx 标注，供肉眼挑选
  pick    144 225 1358            按 idx 下原图到 work/pick/，并回显真实尺寸与标题
  finalize --plan picks.json      按指定顺序复制成中文名成品 + 生成来源说明

工作区默认 ./配图工作区，成品目录默认 ./微头条配图，均可用 --work / --out 覆盖。

关键设计（血泪换来的，别改）：
  * idx 在候选入库时一次性写死，之后只追加不重排；否则 pick 会下错图。
  * 宁可少抓，不要连发：请求间隔 >= 2.5s，必须带 Referer: https://image.baidu.com/，
    否则百度返回 HTML 而不是 JSON。
  * 百度原图地址（objURL）是加密的，必须解密后才能拿到真实大图；
    middleURL 只有 500px，只能当缩略图用，别当成品。
  * 长任务请后台跑，并加 -u；否则输出被缓冲，看不到进度还会被前台超时打断。
"""

import argparse
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")

# ---------------------------------------------------------------- 图源白名单

# 允许的图源平台（写死，不要扩展）
ALLOWED_PLATFORMS = ("百度图片", "小红书")

SEARCH = "https://image.baidu.com/search/acjson"
REFERER = "https://image.baidu.com/"
HDR = {"User-Agent": UA, "Referer": REFERER,
       "Accept": "application/json, text/plain, */*"}

# 百度搜索接口的固定参数（少一个都可能被反爬挡掉返回 HTML）
BASE_PARAMS = {
    "tn": "resultjson_com", "logid": "1", "ipn": "rj", "ct": "201326592",
    "is": "", "fp": "result", "fr": "", "cl": "2", "lm": "-1",
    "ie": "utf-8", "oe": "utf-8", "st": "-1", "z": "", "ic": "", "hd": "",
    "latest": "", "copyright": "", "s": "", "se": "", "tab": "",
    "width": "", "height": "", "face": "0", "istype": "2", "qc": "",
    "nc": "1", "expermode": "", "nojc": "", "isAsync": "", "gsm": "1e",
}

# 图库 / 电商 / 带货站：出现在 fromURLHost 里就直接丢，不进候选。
# 这些站的图有版权风险，且九成是白底商品图，与本技能铁律冲突。
HOST_DENY = (
    "vcg.com", "veer.com", "699pic", "58pic", "588ku", "zcool.com.cn",
    "nitu", "tukuppt", "pngtree", "lovepik", "bigstock", "shutterstock",
    "gettyimages", "dpm.org.cn", "photophoto",
    "51miz", "mizhi", "ooopic", "tooopen", "16pic", "zhituwang", "qiantu",
    "sucai999", "51yuansu", "chuangkit", "tupian114", "ztupic", "7788.com",
    "taobao.com", "tmall.com", "jd.com", "1688.com", "pinduoduo",
    "alibaba.com", "made-in-china", "17zwd", "yiwugo",
)

DEFAULT_WORK = "配图工作区"
DEFAULT_OUT = "微头条配图"


# ---------------------------------------------------------------- 基础

def die(msg):
    print("✗ " + msg, flush=True)
    sys.exit(1)


def need_deps():
    try:
        import requests  # noqa: F401
    except ImportError:
        die("缺少 requests。请用隔离环境安装：\n"
            "  ~/.workbuddy/binaries/python/versions/3.13.12/bin/python3 -m venv ~/.workbuddy/binaries/python/envs/default\n"
            "  ~/.workbuddy/binaries/python/envs/default/bin/pip install pillow requests")
    try:
        import PIL  # noqa: F401
    except ImportError:
        die("缺少 Pillow。请执行：\n"
            "  ~/.workbuddy/binaries/python/envs/default/bin/pip install pillow requests")


def paths(work):
    work = os.path.abspath(work)
    return {
        "work": work,
        "raw": os.path.join(work, "raw"),
        "pick": os.path.join(work, "pick"),
        "cj": os.path.join(work, "candidates.json"),
    }


def load_cj(p):
    if os.path.exists(p["cj"]):
        try:
            return json.load(open(p["cj"], encoding="utf-8"))
        except Exception:
            die("candidates.json 损坏，删掉重跑 harvest 即可。")
    return []


def save_cj(p, items):
    json.dump(items, open(p["cj"], "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def ext_of(url):
    m = re.search(r"\.(jpg|jpeg|png|webp)", (url or "").lower())
    return "." + m.group(1) if m else ".jpg"


def clean_title(s):
    """百度标题里夹着 <strong> 高亮和省略号，清掉。"""
    s = re.sub(r"<[^>]+>", "", s or "")
    s = s.replace("\u3000", " ").strip()
    return re.sub(r"\s+", " ", s)[:90]


def is_xhs(host):
    h = (host or "").lower()
    return "xiaohongshu" in h or "xhscdn" in h


# ---------------------------------------------------------------- objURL 解密
# 百度把原图地址加密成 "ippr..." 开头的串。不解密只能拿到 500px 的 middleURL。
# 这套映射是百度的老编码，2026-11 实测仍然有效。

_STR_TABLE = (("_z2C$q", ":"), ("_z&e3B", "."), ("AzdH3F", "/"))
_CH_TABLE = {
    "w": "a", "k": "b", "v": "c", "1": "d", "j": "e", "u": "f", "2": "g",
    "i": "h", "t": "i", "3": "j", "h": "k", "s": "l", "4": "m", "g": "n",
    "5": "o", "r": "p", "q": "q", "6": "r", "f": "s", "p": "t", "7": "u",
    "e": "v", "o": "w", "8": "1", "d": "2", "n": "3", "9": "4", "c": "5",
    "m": "6", "0": "7", "b": "8", "l": "9", "a": "0",
}


def decode_url(u):
    """把百度的加密地址还原成可直下的 http(s) 地址；已经是明文就原样返回。"""
    if not u:
        return ""
    if not u.startswith("ippr"):
        return u
    body = u[4:]
    for k, v in _STR_TABLE:
        body = body.replace(k, v)
    # 解密结果的首字符是 "s"（代表 https），所以要补回 "http"
    return "http" + "".join(_CH_TABLE.get(c, c) for c in body)


def item_link(it):
    """来源页地址：优先 replaceUrl 里给的明文，其次解密 fromURL。"""
    ru = it.get("replaceUrl") or []
    if isinstance(ru, list) and ru:
        s = (ru[0] or {}).get("FromURL") or (ru[0] or {}).get("ObjURL") or ""
        if s.startswith("http"):
            return s
    return decode_url(it.get("fromURL") or "")


def loads_tolerant(txt):
    """百度偶尔返回非法转义（`\'` 之类），直接 json.loads 会整页报废。
    兜底：把不成对的单反斜杠补成双反斜杠再解一次。"""
    try:
        return json.loads(txt)
    except json.JSONDecodeError:
        fixed = re.sub(r'\\(?!["\\/bfnrtu])', r"\\\\", txt)
        return json.loads(fixed, strict=False)


# ---------------------------------------------------------------- 抓取

def fetch(keyword, pn, tries=4):
    """返回 (list, err)。err 非空表示这一轮彻底失败，让调用方决定要不要退避。"""
    import requests
    last = ""
    for t in range(tries):
        try:
            params = dict(BASE_PARAMS)
            params.update({"word": keyword, "queryWord": keyword,
                           "pn": str(pn), "rn": "30"})
            r = requests.get(SEARCH, params=params, headers=HDR, timeout=20)
            txt = r.text.strip()
            if not txt.startswith("{"):
                # 被限流时百度返回 HTML
                last = "非 JSON 响应（疑似限流）"
                time.sleep(5 + 6 * t)
                continue
            data = loads_tolerant(txt).get("data") or []
            return [x for x in data if x], ""
        except Exception as e:
            last = f"{type(e).__name__}: {e}"
            time.sleep(4 + 5 * t)
    return [], last


# ---------------------------------------------------------------- doctor

def cmd_doctor(args):
    need_deps()
    p = paths(args.work)
    print("依赖 OK；工作区：", p["work"])
    print("图源白名单：%s（脚本自动化只用百度）" % " / ".join(ALLOWED_PLATFORMS))

    lst, err = fetch("工厂车间", 0)
    if lst:
        hosts = {}
        for x in lst:
            h = (x.get("fromURLHost") or "?").lower()
            hosts[h] = hosts.get(h, 0) + 1
        print(f"百度图片 OK：本次命中 {len(lst)} 条")
        for h, n in sorted(hosts.items(), key=lambda kv: -kv[1])[:5]:
            print(f"   {h}  {n}")
    else:
        die(f"百度图片不通：{err}\n"
            "若为『非 JSON 响应』，说明被限流：等 1~2 分钟，或把请求间隔调到 4 秒以上。")

    print("小红书：站点可达，但搜索页是纯前端渲染 + 需登录态，脚本抓不到（按设计，不直抓）。")
    print("         需要小红书图时走 SKILL.md「小红书怎么用」里的两条人工路径。")


# ---------------------------------------------------------------- harvest

def cmd_harvest(args):
    need_deps()
    import requests
    plan = json.load(open(args.plan, encoding="utf-8"))
    groups = plan.get("groups") or {}
    if not groups:
        die("plan.json 里没有 groups，格式：{\"groups\":{\"场景名\":[\"关键词1\",\"关键词2\"]}}")

    p = paths(args.work)
    os.makedirs(p["raw"], exist_ok=True)
    items = load_cj(p)
    have = {x["img"] for x in items}
    print(f"已有候选 {len(items)} 条", flush=True)
    print(f"图源：百度图片（白名单：{'/'.join(ALLOWED_PLATFORMS)}，仅百度自动化）", flush=True)

    pages = tuple(int(x) for x in args.pages.split(",")) if args.pages else (0, 30)
    dropped_deny = 0
    dropped_src = 0

    for key, kws in groups.items():
        for kw in kws:
            for pn in pages:
                lst, err = fetch(kw, pn)
                if err and not lst:
                    print(f"  ! {kw} pn={pn} 放弃：{err}", flush=True)
                added = 0
                for it in lst:
                    img = decode_url(it.get("objURL") or "")
                    mid = it.get("middleURL") or ""
                    th = it.get("thumbURL") or ""
                    thumb = mid or th
                    if not img or not thumb or img in have:
                        continue
                    host = (it.get("fromURLHost") or "").lower()
                    if any(d in host for d in HOST_DENY):
                        dropped_deny += 1
                        continue
                    if args.src == "xhs" and not is_xhs(host):
                        dropped_src += 1
                        continue
                    have.add(img)
                    try:
                        w, h = int(it.get("width") or 0), int(it.get("height") or 0)
                    except Exception:
                        w, h = 0, 0
                    idx = len(items)
                    items.append({
                        "key": key, "q": kw, "title": clean_title(it.get("fromPageTitleEnc")),
                        "img": img, "thumb": thumb, "w": w, "h": h,
                        "site": host, "link": item_link(it),
                        "src": "小红书" if is_xhs(host) else "百度图片",
                        "idx": idx, "file": f"{key}_{idx:04d}{ext_of(img)}",
                    })
                    added += 1
                print(f"  {key} | {kw} pn={pn} +{added}", flush=True)
                save_cj(p, items)          # 每轮落盘，崩了也不丢
                time.sleep(max(2.5, args.sleep))

    todo = [x for x in items if not x.get("ok")]

    def dl(it):
        path = os.path.join(p["raw"], it["file"])
        if os.path.exists(path) and os.path.getsize(path) > 3000:
            it["ok"] = True
            return
        for t in range(3):
            try:
                r = requests.get(it["thumb"],
                                 headers={"User-Agent": UA, "Referer": REFERER},
                                 timeout=20)
                if r.status_code == 200 and len(r.content) > 1500:
                    open(path, "wb").write(r.content)
                    it["ok"] = True
                    return
            except Exception:
                time.sleep(1 + t)
        it["ok"] = False

    with ThreadPoolExecutor(max_workers=8) as ex:
        list(ex.map(dl, todo))
    save_cj(p, items)

    per = {}
    for x in items:
        if x.get("ok"):
            per[x["key"]] = per.get(x["key"], 0) + 1
    print(f"候选 {len(items)} 条，可用缩略图 {sum(per.values())} 张"
          f"（丢图库/电商站 {dropped_deny} 条"
          + (f"，非小红书源 {dropped_src} 条" if args.src == "xhs" else "") + "）", flush=True)
    for k, v in per.items():
        print(f"  {k}: {v}")


# ---------------------------------------------------------------- sheet

def cmd_sheet(args):
    need_deps()
    from PIL import Image, ImageDraw
    p = paths(args.work)
    items = load_cj(p)
    if not items:
        die("候选为空，先跑 harvest")
    keys = [args.key] if args.key else sorted({x["key"] for x in items})
    cols, rows, per = 6, 4, 24
    CW, CH, LAB = 300, 232, 26
    outs = []
    for key in keys:
        sel = [x for x in items
               if x["key"] == key and x.get("ok")
               and x.get("w", 0) >= 600 and x.get("h", 0) >= 400
               and 0.55 <= x["w"] / max(1, x["h"]) <= 2.2]
        sel.sort(key=lambda x: -(x["w"] * x["h"]))
        pages = min(args.pages, (len(sel) + per - 1) // per)
        for pg in range(pages):
            chunk = sel[pg * per:(pg + 1) * per]
            sheet = Image.new("RGB", (cols * CW, rows * CH), "white")
            d = ImageDraw.Draw(sheet)
            for i, it in enumerate(chunk):
                r, c = divmod(i, cols)
                x, y = c * CW, r * CH
                try:
                    im = Image.open(os.path.join(p["raw"], it["file"])).convert("RGB")
                    im.thumbnail((CW - 8, CH - LAB - 8))
                    sheet.paste(im, (x + (CW - im.width) // 2, y + (CH - LAB - im.height) // 2))
                except Exception:
                    d.text((x + 10, y + 60), "ERR", fill="red")
                d.text((x + 6, y + CH - LAB + 4), f"{it['idx']}  {it['w']}x{it['h']}", fill="black")
            out = os.path.join(p["work"], f"sheet_{key}_{pg}.jpg")
            sheet.save(out, quality=80)
            outs.append(out)
        print(f"{key}: 合格缩略图 {len(sel)} 张，出 {pages} 版")
    for o in outs:
        print(o)


# ---------------------------------------------------------------- pick

def cmd_pick(args):
    need_deps()
    import requests
    from PIL import Image
    p = paths(args.work)
    os.makedirs(p["pick"], exist_ok=True)
    by_idx = {x["idx"]: x for x in load_cj(p)}
    for s in args.idx:
        i = int(s)
        if i not in by_idx:
            print(f"✗ {i} 不在候选里（会被跳过的 idx 请回联系表重新确认）")
            continue
        it = by_idx[i]
        dst = os.path.join(p["pick"], f"{i}.jpg")
        if not (os.path.exists(dst) and os.path.getsize(dst) > 5000):
            ok = False
            # 顺序：原图（带来源站 Referer）→ 原图（带百度 Referer）→ 500px 代理。
            # 来源站的图床常校验本站 Referer，只带百度 Referer 会 403，白丢原图。
            site_ref = it.get("link") or ""
            site_ref = re.sub(r"(https?://[^/]+).*", r"\1/", site_ref) if site_ref else ""
            tries = []
            if it.get("img"):
                if site_ref:
                    tries.append((it["img"], site_ref))
                tries.append((it["img"], REFERER))
                # 政府站/老站点的 HTTPS 常常是坏的（SSL EOF），降级到 http 才给图
                if it["img"].startswith("https://"):
                    u_http = "http://" + it["img"][len("https://"):]
                    if site_ref:
                        tries.append((u_http, site_ref.replace("https://", "http://")))
                    tries.append((u_http, REFERER))
            if it.get("thumb"):
                tries.append((it["thumb"], REFERER))
            for url, ref in tries:
                try:
                    r = requests.get(url, headers={"User-Agent": UA, "Referer": ref}, timeout=25)
                    if r.status_code == 200 and len(r.content) > 5000:
                        open(dst, "wb").write(r.content)
                        ok = True
                        break
                except Exception:
                    pass
            if not ok:
                print(f"✗ {i} 原图下载失败，可改用缩略图或换图")
                continue
        try:
            im = Image.open(dst)
            real = f"{im.width}x{im.height}"
        except Exception:
            print(f"✗ {i} 不是有效图片")
            continue
        warn = "" if real == f"{it['w']}x{it['h']}" else f"  (声明 {it['w']}x{it['h']}，实测 {real})"
        src = it.get("src", "百度图片")
        print(f"{i} | {it['key']} | {src} | {real} | {round(os.path.getsize(dst)/1024)}KB | "
              f"{it['title'][:44]}{warn}")


# ---------------------------------------------------------------- finalize

def cmd_finalize(args):
    need_deps()
    import shutil
    from PIL import Image
    p = paths(args.work)
    out = os.path.abspath(args.out)
    os.makedirs(out, exist_ok=True)
    picks = json.load(open(args.plan, encoding="utf-8"))
    if not isinstance(picks, list) or not picks:
        die("picks.json 必须是数组：[{\"idx\":144,\"name\":\"01 车间老师傅.jpg\",\"beat\":\"对应正文哪句\"}]")
    by_idx = {x["idx"]: x for x in load_cj(p)}
    lines, made = [], []
    for i, item in enumerate(picks, 1):
        idx, name = int(item["idx"]), item.get("name") or f"{i:02d}.jpg"
        src = os.path.join(p["pick"], f"{idx}.jpg")
        if not os.path.exists(src):
            print(f"✗ {idx} 还没 pick 下来，先跑 pick")
            continue
        dst = os.path.join(out, name)
        shutil.copy(src, dst)
        im = Image.open(dst)
        it = by_idx.get(idx, {})
        lines.append(f"{name}\n  尺寸 {im.width}x{im.height}　大小 {round(os.path.getsize(dst)/1024)}KB\n"
                     f"  对应正文 {(item.get('beat') or '—')}\n"
                     f"  图源 {it.get('src', '百度图片')}　原标题 {it.get('title', '')}\n"
                     f"  来源页 {it.get('link') or it.get('site', '')}\n")
        made.append(dst)
        print(f"✓ {name}  {im.width}x{im.height}")

    note = os.path.join(out, "图片来源说明.txt")
    open(note, "w", encoding="utf-8").write(
        "以下图片均检索自公开图源（百度图片 / 小红书），为纪实实拍图，非广告物料，仅供配图参考。\n"
        "不采用图库站（视觉中国、摄图网等）与电商商品图。\n"
        "如需商用或大范围传播，请自行核验版权。\n\n" + "\n".join(lines))
    made.append(note)
    print(f"\n成品目录：{out}\n共 {len(made)-1} 张图 + 1 份来源说明")
    print("下一步：用 present_files 一次性打开这些文件。")
    for m in made:
        print(m)


# ---------------------------------------------------------------- CLI

def main():
    ap = argparse.ArgumentParser(description="微头条配图流水线（图源：百度图片 / 小红书）")
    ap.add_argument("--work", default=DEFAULT_WORK, help="工作区目录（默认 ./配图工作区）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("doctor", help="检查依赖与图源连通性")

    h = sub.add_parser("harvest", help="按关键词计划抓候选图")
    h.add_argument("--plan", required=True)
    h.add_argument("--pages", default="0,30",
                   help="翻页位置，逗号分隔，默认 0,30（一般到 60 就没新东西了）")
    h.add_argument("--src", default="all", choices=["all", "xhs"],
                   help="all=百度全部结果；xhs=只要来源站是小红书的那几条（量很少）")
    h.add_argument("--sleep", type=float, default=2.5,
                   help="请求间隔秒数，默认 2.5，被限流时调大到 4")

    s = sub.add_parser("sheet", help="生成联系表")
    s.add_argument("--key", default=None, help="只出某一组，默认全部")
    s.add_argument("--pages", type=int, default=2, help="每组最多出几版，默认 2")

    k = sub.add_parser("pick", help="按 idx 下原图")
    k.add_argument("idx", nargs="+")

    f = sub.add_parser("finalize", help="出品成品并写来源说明")
    f.add_argument("--plan", required=True)
    f.add_argument("--out", default=DEFAULT_OUT)

    args = ap.parse_args()
    {"doctor": cmd_doctor, "harvest": cmd_harvest, "sheet": cmd_sheet,
     "pick": cmd_pick, "finalize": cmd_finalize}[args.cmd](args)


if __name__ == "__main__":
    main()
